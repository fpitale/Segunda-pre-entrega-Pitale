#mi proyecto 

'''bash
pip install .

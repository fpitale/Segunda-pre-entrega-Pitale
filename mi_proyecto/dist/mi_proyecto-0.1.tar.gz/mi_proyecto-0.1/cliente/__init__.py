# cliente/__init__.py

from .cliente import Cliente
